// make text boxes usable with dark themes
pref("widget.content.gtk-theme-override", "Bunsen-He");
